o900 sub
    G91
    #<total_v> = 0

    #<while_i> = 0
    o901 while [#<while_i> LT #1]
        #<back_v> = #3
        #<while_i> = [#<while_i> + 1]
        o903 if [#<while_i> EQ #1]
			#<back_v> = 0
		o903 endif
        o902 if [#2 EQ 1]
            G80 X+
            #<total_v> = #<total_v> + #<_x>
            M05 G00 X[-#<back_v>]
        o902 elseif [#2 EQ 2]
            G80 X-
            #<total_v> = #<total_v> + #<_x>
            M05 G00 X[#<back_v>]
		o902 elseif [#2 EQ 11]
            G80 Y+
			#<total_v> = #<total_v> + #<_y>
			M05 G00 Y[-#<back_v>]
		o902 elseif [#2 EQ 12]
            G80 Y-  
			#<total_v> = #<total_v> + #<_y>
			M05 G00 Y[#<back_v>]
		o902 elseif [#2 EQ 21]
			G80 Z+
			#<total_v> = #<total_v> + #<_z>
			M05 G00 Z[-#<back_v>]
		o902 elseif [#2 EQ 22]
            G80 Z-
			#<total_v> = #<total_v> + #<_z>
			M05 G00 Z[#<back_v>]
        o902 endif
    o901 endwhile
    G90
    o900 return [#<total_v> / #1]
o900 endsub
o900 call [4] [12] [0.100]
M05 G90 G00 Y #<_value>
G91 M05 G00 Y1.000