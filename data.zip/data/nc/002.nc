
o900 sub
    G91
    #<total_v> = 0

    #<while_i> = 0
    o901 while [#<while_i> LT #1]
        #<back_v> = #3
        #<while_i> = [#<while_i> + 1]
        o903 if [#<while_i> EQ #1]
			#<back_v> = 0
		o903 endif
        o902 if [#2 EQ 1]
            G80 X+
            #<total_v> = #<total_v> + #<_x>
            M05 G00 X[-#<back_v>]
        o902 elseif [#2 EQ 2]
            G80 X-
            #<total_v> = #<total_v> + #<_x>
            M05 G00 X[#<back_v>]
		o902 elseif [#2 EQ 11]
            G80 Y+
			#<total_v> = #<total_v> + #<_y>
			M05 G00 Y[-#<back_v>]
		o902 elseif [#2 EQ 12]
            G80 Y-  
			#<total_v> = #<total_v> + #<_y>
			M05 G00 Y[#<back_v>]
		o902 elseif [#2 EQ 21]
			G80 Z+
			#<total_v> = #<total_v> + #<_z>
			M05 G00 Z[-#<back_v>]
		o902 elseif [#2 EQ 22]
            G80 Z-
			#<total_v> = #<total_v> + #<_z>
			M05 G00 Z[#<back_v>]
        o902 endif
    o901 endwhile
    G90
    o900 return [#<total_v> / #1]
o900 endsub

o901 sub
G91
G83 X011
G91 G00 X-6
G91 G00 Z-5.000
G83 X013
o900 call [4] [1] [1.000]
#<_H1>=#<_value>
M05 G91 G00 X-1
G90 G00 XH013
G91 G00 Z+5.000
G90 G00 XH011
G83 X011
G91 G00 X+6
G91 G00 Z-5.000
G83 X013
o900 call [4] [2] [1.000]
#<_H2>=#<_value>
M05 G91 G00 X+1
G90 G00 XH013
G91 G00 Z+5.000
G90 G00 X[[H001+H002]/2]
G83 Y011
G91 G00 Y-6
G91 G00 Z-5.000
G83 Y013
o900 call [4] [11] [1.000]
#<_H3>=#<_value>
M05 G91 G00 Y-1
G90 G00 YH013
G91 G00 Z+5.000
G90 G00 YH011
G83 Y011
G91 G00 Y+6
G91 G00 Z-5.000
G83 Y013
o900 call [4] [12] [1.000]
#<_H4>=#<_value>
M05 G91 G00 Y+1
G90 G00 YH013
G91 G00 Z+5.000
G90 G00 Y[[H003+H004]/2]
H009 = [[H001+H002]/2]
H007 = [[H003+H004]/2]
H008 = [[H002-H001]/2]
H010 = [[H004-H003]/2]
(debug, do_call_ui #<_H9>,#<_H7>,#<_H8>,#<_H10>)
G90
o901 endsub

o901 call
o901 call
do_beep 100
