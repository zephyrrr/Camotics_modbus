g00 x34

g00 y-23

g00 z34
fdsfdsf
